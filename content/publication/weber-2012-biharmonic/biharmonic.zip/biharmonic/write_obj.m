function write_obj(data,coords,cage)
load(data)
fid=fopen(coords,'wt');
fprintf(fid,'v %.4f %.4f 0.00\n',Xc');
fclose(fid);

fid=fopen(cage,'w');
fprintf(fid,'v %.4f %.4f 0.00\n',f');
fclose(fid);
end

