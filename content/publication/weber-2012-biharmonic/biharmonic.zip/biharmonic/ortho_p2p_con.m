function [c,ceq,Gc,Gceq] = ortho_p2p_con(x,i,j)
c=[];
k=length(x)/4;
f=[x(1:k),x(k+1:2*k)];
n=[x(2*k+1:3*k),x(3*k+1:4*k)];



f_new=[f(2:end,:)-f(1:end-1,:);f(1,:)-f(end,:)];
J=[f_new(:,1),f_new(:,2),n(:,1),n(:,2)];

val=J(:,1).*J(:,3)+J(:,2).*J(:,4);
ceq=[val;J(:,3).^2+J(:,4).^2-1];

%c=J(:,1).*J(:,4)-J(:,2).*J(:,3);

if nargout > 2

    vals1=[-n(:,1),n(:,1),-n(:,2),n(:,2),f_new(:,1),f_new(:,2)]';
    vals1(1:4,end)=-vals1(1:4,end);
    vals2=2*n';
    s=[vals1(:);vals2(:)];
    Gceq = sparse(i,j,s,4*k,2*k);
    Gc = [];
end
end

