%% draw polygon
close all
clear vars
filename = 'bar';
[X,Faces] = read_off([filename '.off']);
% X(:,1)=(X(:,1)-min(X(:,1)))./(max(X(:,1)-min(X(:,1))));
% X(:,2)=(X(:,2)-min(X(:,2)))./(max(X(:,2)-min(X(:,2))));
T = faces2tri(Faces);

patch('Faces',T,'Vertices',X,'FaceColor','w'); axis equal; hold on; grid minor
aa = axis;
aa = aa + [-1,1,-1,1];
axis(aa);

% [x,y] = getline(gcf,'closed');
% x = x(1:end-1); y = y(1:end-1);

x=[-24.1,-24.1,24.1,24.1]';
y=[5.1,-5.1,-5.1,5.1]';
zb=x+1i*y;
n=-1i*[zb(2:end)-zb(1:end-1);zb(1)-zb(end)];
%meps=max(eps(zb));
meps=1e-1;
n=(n./abs(n));
n=[n(1)+n(end);n(2:end)+n(1:end-1)];
n=meps.*(n./abs(n));
zb=zb+n;
x=real(zb); y=imag(zb);

drawPolygon(x,y);
draw_point_2d([x,y],'MarkerSize',30);
xp=[-23,0,23]';
yp=[0,0,0]';
draw_point_2d([xp,yp],'color','r','MarkerSize',10);
xp_new=[-23,0,23]';
yp_new=[0,30,0]';
draw_point_2d([xp_new,yp_new],'color','y','MarkerSize',10);
%% compute stuff
npinned = length(x);
zb = x +1i*y;
Hs = build_sampling_matrix(zb, 0.5, 1, 0);
zbs=Hs*zb;
createIndMat(length(zbs));

z = X(:,1) + 1i*X(:,2);
[Phi,Psi,Alpha,Beta] = build_green_biharmonic_matrix(z, zbs);
[Phip,Psip,Alphap,Betap] = build_green_biharmonic_matrix(xp+1i*yp, zbs);
[Phib,Phibddn,Psib,Psibddn,Alphab,Alphabddn,Betab,Betabddn,H,zt] = build_green_biharmonic_dd_matrix_boundary(zbs, 10);

Hn=(H~=0);idx = repmat({':'}, ndims(Hn), 1);n = size(Hn, 2);idx{2} = [ 2:n 1 ];Hn=Hn+Hn(idx{:});Hn=(Hn==2);


Xc = X;


patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
drawPolygon(x,y);
draw_point_2d([x,y],'MarkerSize',30);

f=[real(zbs); imag(zbs)];

k2l=pinv(Psib)*(Phib-H);
M=pinv(Alphab-Betab*k2l);
M1=(Alphabddn-Betabddn*k2l)*M;
M2=(Phibddn-M1*(Phib-H));
M3=(-Psibddn+M1*Psib);
load ind_ij;
%% deform
steps=10;
t=linspace(0,1,steps);
xm=xp*(1-t)+xp_new*t;
ym=yp*(1-t)+yp_new*t;
times=[];
for i=2:steps;
    figure(1)
    xp(:) = xm(:,i); yp(:) = ym(:,i);
    
%     n=[f(2:end,:)-f(1:end-1,:);f(1,:)-f(end,:)]; n=[-n(:,2),n(:,1)];
%     n=n./repmat(sqrt(sum(n.^2,2)),1,2);
    

    x0=f; %f
    
    Aeq=zeros(2*size(Phip,1),4*size(Phip,2));
    Aeq(1:size(Phip,1),1:size(Phip,2))=Phip-(Alphap-Betap*k2l)*M*(Phib-H);
    Aeq(1:size(Phip,1),2*size(Phip,2)+1:3*size(Phip,2))=-Psip-(Alphap-Betap*k2l)*M*(-Psib);
    Aeq(size(Phip,1)+1:2*size(Phip,1),size(Phip,2)+1:2*size(Phip,2))=Phip-(Alphap-Betap*k2l)*M*(Phib-H);
    Aeq(size(Phip,1)+1:2*size(Phip,1),3*size(Phip,2)+1:4*size(Phip,2))=-Psip-(Alphap-Betap*k2l)*M*(-Psib);
    
   
    
    options = optimset('MaxIter',100,'Algorithm','interior-point','GradObj','off','Display','off');...'DerivativeCheck','on');%,...
                               % 'PlotFcns',@(x,optimValues,state)draw_deform(x, optimValues, state,Phi,Psi,Alpha,Beta,k2l,M,Phib,H,Psib,xp,yp,T));
    tic;
    x = fmincon(@(x)thickness_onlyf(x,M2,M3),x0,...
                               [],[],Aeq,[xp;yp],[],[],[],options);
	times=[times;toc];
    f=reshape(x(1:2*length(zbs)),[],2);
    n=reshape(x(2*length(zbs)+1:end),[],2);
    Xc=Phi*f-Psi*n-(Alpha-Beta*k2l)*M*((Phib-H)*f-Psib*n);
    
    figure(1)
    cla
    patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
    drawPolygon(f(:,1),f(:,2));
    draw_point_2d([xp,yp],'MarkerSize',30);
    axis(aa)
    title('Biharmonic');

end
