%% draw polygon
close all
filename = 'bar';
[X,Faces] = read_off([filename '.off']);
T = faces2tri(Faces);

patch('Faces',T,'Vertices',X,'FaceColor','w'); axis equal; hold on; grid minor
aa = axis;
aa = aa + [-1,1,-1,1];
axis(aa);

[x,y] = getline(gcf,'closed');
x = x(1:end-1); y = y(1:end-1);
drawPolygon(x,y);
draw_point_2d([x,y],'MarkerSize',30);

%% compute stuff
npinned = length(x);

zb = x +1i*y;
Hs = build_sampling_matrix(zb, 1, 1, 0);
zbs=Hs*zb;

z = X(:,1) + 1i*X(:,2);
[Phi,Psi,Alpha,Beta] = build_green_biharmonic_matrix(z, zbs);
[Phib,Psib,Alphab,Betab,H,zt] = build_green_biharmonic_matrix_boundary(zbs, 10);

Hn=(H~=0);idx = repmat({':'}, ndims(Hn), 1);n = size(Hn, 2);idx{2} = [ 2:n 1 ];Hn=Hn+Hn(idx{:});Hn=(Hn==2);


Xc = X;
xpinned = [x,y];


patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
drawPolygon(xpinned(:,1),xpinned(:,2));
draw_point_2d(xpinned,'MarkerSize',30);

%% deform
while (1)
    l1 = pick_vertex(xpinned);
    draw_point_2d(xpinned(l1,:),'MarkerSize',30,'color','r');
    [zx,zy] = ginput(1);
    xpinned(l1,:) = [zx,zy];
    f=Hs*xpinned;
    n=[f(2:end,:)-f(1:end-1,:);f(1,:)-f(end,:)]; n=[-n(:,2),n(:,1)];
    n=n./repmat(sqrt(sum(n.^2,2)),1,2);
    
    k2l=pinv(Psib)*(Phib-H);
    cvx_begin
        variables s(length(f),1);
        variables l(length(f),2);
        minimize(norm(l,'fro')+...
                              norm((Phib-H)*f-Psib*([s,s].*n)+(Alphab-Betab*k2l)*l,'fro'))
        subject to
            s>0.1
    cvx_end

    
    Xc=Phi*f-Psi*([s,s].*n)+Alpha*l-Beta*k2l*l;
    
    cla
    patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
    drawPolygon(xpinned(:,1),xpinned(:,2));
    draw_point_2d(xpinned,'MarkerSize',30);
    axis(aa)
    title('Biharmonic');

end
