function [Phi,Psi,Alpha,Beta] = build_green_biharmonic_matrix(z, zb)
n = length(z);
m = length(zb);
Phi=zeros(n,m);
Psi=zeros(n,m);
Alpha=zeros(n,m);
Beta=zeros(n,m);

for j=1:m
    jp1 = j+1; if jp1 > m jp1 = 1; end;
    jm1 = j-1; if jm1 == 0 jm1 = m; end;
    zbjm1 = zb(jm1); zbj = zb(j); zjp1 = zb(jp1);
    
    Aj=zjp1-zbj;
    c=abs(Aj);
    x=real(c*(z-zbj)/Aj);
    y=imag(c*(z-zbj)/Aj);
    Log1=log(x.^2+y.^2);
    Log2=log(x.^2+y.^2+c.^2-2*x.*c);
    Atan=atan(x./y) + atan((c - x)./y);
   
    Psi(:,j)=(-1/(4*pi))*(2*y.*Atan+x.*Log1-2*c+(c-x).*Log2);
    Phi(:,jp1)=Phi(:,jp1)+(1/(4*pi))*(2*x.*Atan-y.*(Log1-Log2))./c;
    Phi(:,j)=Phi(:,j)+(1/(2*pi))*Atan-(1/(4*pi))*(2*x.*Atan-y.*(Log1-Log2))./c;
    
    Beta(:,j)=(-1/(144*pi))*(Log1.*(3*x.*(3*y.^2+x.^2))+Log2*3.*(c-x).*(c.^2-2*x.*c+3*y.^2+x.^2)+Atan*12.*y.^3+24*(x.*c.^2-c.*x.^2)-8*c.^3-30*c.*y.^2);
    Alpha(:,jp1)=Alpha(:,jp1)+(1./(16*pi*c)).*(4*Atan.*x.*y.^2-Log2.*y.*(x.^2-y.^2-c.^2)+Log1.*y.*(x.^2-y.^2)-2*y.*c.*(c+x));
    Alpha(:,j)=Alpha(:,j)...
        -0.5*y.*(-1/(4*pi)).*(2*y.*Atan+x.*Log1-2*c+(c-x).*Log2)...
        -(1/(8*pi))*y.*c-(1./(16*pi*c)).*(4*Atan.*x.*y.^2-Log2.*y.*(x.^2-y.^2-c.^2)+Log1.*y.*(x.^2-y.^2)-2*y.*c.*(c+x));
end
