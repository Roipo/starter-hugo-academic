function T = faces2tri(Faces)

nf = length(Faces);
T = reshape(cell2mat(Faces),3,nf)';