function createIndMat(n)
A=[[toeplitz([1,1,zeros(1,n-2)],[1,zeros(1,n-2),1]);toeplitz([1,1,zeros(1,n-2)],[1,zeros(1,n-2),1]);eye(n);eye(n)],[zeros(2*n,n);eye(n);eye(n)]];
[ind_i,ind_j]=find(A);
save('ind_ij.mat','ind_i','ind_j');