function drawPolygon(x,y, varargin)

plot(x,y,varargin{:});