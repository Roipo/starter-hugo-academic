function [F,G] = thickness(x,M2,M3)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
k=length(x)/4;
f=[x(1:k),x(k+1:2*k)];
n=[x(2*k+1:3*k),x(3*k+1:4*k)];
T=M2*f+M3*n;
F=norm(T,'fro')^2;
if nargout>1
    G=zeros(length(x),1);
    G(1:2*k)=2*M2'*T;
    G(2*k+1:4*k)=2*M3'*T;
end


