function draw_point_2d(pt,varargin);

h = plot(pt(:,1),pt(:,2),'.','MarkerSize',20);
if length(varargin)>0
    set(h, varargin{:});
end