function [Phi,Phiddn,Psi,Psiddn,Alpha,Alphaddn,Beta,Betaddn,H,zb] = build_green_biharmonic_dd_matrix_boundary(zb, dens)
n=-1i*[zb(2:end)-zb(1:end-1);zb(1)-zb(end)];
%meps=max(eps(zb));
meps=1e-6;
n=meps.*(n./abs(n));
n=[n(1)+n(end);n(2:end)+n(1:end-1)];
zb_offset=zb+n;
H = build_sampling_matrix(zb, dens, 0, 0);
z=H*zb;
zdn=H*(zb-n);
z2dn=H*(zb-2*n);
zb = zb_offset;


n = length(z);
m = length(zb);
Phi=zeros(n,m);
Phiddn=zeros(n,m);
Psi=zeros(n,m);
Psiddn=zeros(n,m);
Alpha=zeros(n,m);
Alphaddn=zeros(n,m);
Beta=zeros(n,m);
Betaddn=zeros(n,m);
for j=1:m
    jp1 = j+1; if jp1 > m jp1 = 1; end;
    jm1 = j-1; if jm1 == 0 jm1 = m; end;
    zbjm1 = zb(jm1); zbj = zb(j); zjp1 = zb(jp1);
    
    Aj=zjp1-zbj;
    c=abs(Aj);
    x=real(c*(z-zbj)/Aj); dx=real(c*(zdn-zbj)/Aj); ddx=real(c*(z2dn-zbj)/Aj);
    y=imag(c*(z-zbj)/Aj);dy=imag(c*(zdn-zbj)/Aj); ddy=imag(c*(z2dn-zbj)/Aj);
    Log1=log(x.^2+y.^2); Log1dn=log(dx.^2+dy.^2); Log1ddn=log(ddx.^2+ddy.^2);
    Log2=log(x.^2+y.^2+c.^2-2*x.*c); Log2dn=log(dx.^2+dy.^2+c.^2-2*dx.*c); Log2ddn=log(ddx.^2+ddy.^2+c.^2-2*ddx.*c); 
    Atan=atan(x./y) + atan((c - x)./y); Atandn=atan(dx./dy) + atan((c - dx)./dy);Atanddn=atan(ddx./ddy) + atan((c - ddx)./ddy);
   
    Psi(:,j)=computePsi(x,y,c,Atan,Log1,Log2);
    Psidn=computePsi(dx,dy,c,Atandn,Log1dn,Log2dn);
    Psiddn(:,j)=(computePsi(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn)-2*Psidn+Psi(:,j))./(meps.^2);
    
    Phi1=computePhi1(x,y,c,Atan,Log1,Log2); Phi2=computePhi2(x,y,c,Atan,Log1,Log2);
    Phi1dn=computePhi1(dx,dy,c,Atandn,Log1dn,Log2dn); Phi2dn=computePhi2(dx,dy,c,Atandn,Log1dn,Log2dn);
    Phi1ddn=computePhi1(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn); Phi2ddn=computePhi2(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn);
    Phi(:,jp1)=Phi(:,jp1)+Phi1;
    Phi(:,j)=Phi(:,j)+Phi2;

    Phiddn(:,jp1)=Phiddn(:,jp1)+(Phi1ddn-2*Phi1dn+Phi1)./(meps.^2);
    Phiddn(:,j)=Phiddn(:,j)+(Phi2ddn-2*Phi2dn+Phi2)./(meps.^2);

    
    Beta(:,j)=computeBeta(x,y,c,Atan,Log1,Log2);
    Betadn=computeBeta(dx,dy,c,Atandn,Log1dn,Log2dn);
    Betaddn(:,j)=(computeBeta(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn)-2*Betadn+Beta(:,j))./(meps.^2);
    
    Alpha1=computeAlpha1(x,y,c,Atan,Log1,Log2); Alpha2=computeAlpha2(x,y,c,Atan,Log1,Log2);
    Alpha1dn=computeAlpha1(dx,dy,c,Atandn,Log1dn,Log2dn); Alpha2dn=computeAlpha2(dx,dy,c,Atandn,Log1dn,Log2dn);
    Alpha1ddn=computeAlpha1(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn); Alpha2ddn=computeAlpha2(ddx,ddy,c,Atanddn,Log1ddn,Log2ddn);

    Alpha(:,jp1)=Alpha(:,jp1)+Alpha1;
    Alpha(:,j)=Alpha(:,j)+Alpha2;
    
    Alphaddn(:,jp1)=Alphaddn(:,jp1)+(Alpha1ddn-2*Alpha1dn+Alpha1)./(meps.^2);
    Alphaddn(:,j)=Alphaddn(:,j)+(Alpha2ddn-2*Alpha2dn+Alpha2)./(meps.^2);
    
end
end

function Psi=computePsi(x,y,c,Atan,Log1,Log2)
Psi=(-1/(4*pi))*(2*y.*Atan+x.*Log1-2*c+(c-x).*Log2);
end

function Phi1=computePhi1(x,y,c,Atan,Log1,Log2)
Phi1=(1/(4*pi))*(2*x.*Atan-y.*(Log1-Log2))./c;
end

function Phi2=computePhi2(x,y,c,Atan,Log1,Log2)
Phi2=(1/(2*pi))*Atan-(1/(4*pi))*(2*x.*Atan-y.*(Log1-Log2))./c;
end

function Beta=computeBeta(x,y,c,Atan,Log1,Log2)
Beta=(-1/(144*pi))*(Log1.*(3*x.*(3*y.^2+x.^2))+Log2*3.*(c-x).*(c.^2-2*x.*c+3*y.^2+x.^2)+Atan*12.*y.^3+24*(x.*c.^2-c.*x.^2)-8*c.^3-30*c.*y.^2);
end

function Alpha1=computeAlpha1(x,y,c,Atan,Log1,Log2)
Alpha1=(1./(16*pi*c)).*(4*Atan.*x.*y.^2-Log2.*y.*(x.^2-y.^2-c.^2)+Log1.*y.*(x.^2-y.^2)-2*y.*c.*(c+x));
end

function Alpha2=computeAlpha2(x,y,c,Atan,Log1,Log2)
Alpha2=-0.5*y.*(-1/(4*pi)).*(2*y.*Atan+x.*Log1-2*c+(c-x).*Log2)...
        -(1/(8*pi))*y.*c-(1./(16*pi*c)).*(4*Atan.*x.*y.^2-Log2.*y.*(x.^2-y.^2-c.^2)+Log1.*y.*(x.^2-y.^2)-2*y.*c.*(c+x));
end