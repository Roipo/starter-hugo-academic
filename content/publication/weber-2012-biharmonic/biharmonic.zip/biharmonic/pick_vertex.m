function v = pick_vertex(X);
    
nv = length(X);
[x,y] = ginput(1);
dd = sqrt(sum((X - repmat([x,y],nv,1)).^2,2));
[~,v] = min(dd);
