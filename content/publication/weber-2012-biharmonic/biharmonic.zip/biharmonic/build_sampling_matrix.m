function [H edgeNum] = build_sampling_matrix(z, dens, st, en)

n = length(z);

I = [];
J = [];
S = [];
edgeNum=[];
for j=1:n
    jp1 = j+1; if jp1 > n jp1 = 1; end;
    l = abs(z(jp1)-z(j));
    ns = round(l*dens);
    t = linspace(0,1,ns+1);
    if st == 0
        t = t(2:end);
    end
    if en == 0
        t = t(1:end-1);
    end
    t = t';
    if isempty(t)
        t=0;
    end
       
    ni = 0; if ~isempty(I), ni = I(end); end;
    In = [ni+1:ni+length(t)]';
    Jn = repmat(j,length(In),1);
    Jnp1 = repmat(jp1,length(In),1);
    Sn = 1-t;
    Snp1 = t;
    
    I = [I;In;In];
    J = [J;Jn;Jnp1];
    S = [S;Sn;Snp1];
    edgeNum=[edgeNum; repmat(j,length(In),1)];
end

H = sparse(I,J,S,I(end),n);

    
    
    