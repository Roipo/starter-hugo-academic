function [F,G]=thickness_f_only(x,M2,M3,objdata)
f=zeros(size(x,1)/2,2);
f(:)=x;
n=[f(2:end,:)-f(1:end-1,:); f(1,:)-f(end,:)];
s=sqrt(sum(n.^2,2));
n=n./[s s];
F=M2*f+M3*[-n(:,2),n(:,1)];
F=sum(F(:).^2);

if nargout>1
    G = thickness_f_only_grad(M2,M3,x,objdata);
    
end
