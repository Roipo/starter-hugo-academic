function createCons(k)
for i = 1:4*k
        x{i} = sprintf('x%d',i);
end

x = sym(x, 'real').';

f=[x(1:k),x(k+1:2*k)];
n=[x(2*k+1:3*k),x(3*k+1:4*k)];

f_new=[f(2:end,:)-f(1:end-1,:);f(1,:)-f(end,:)];
J=[f_new(:,1),f_new(:,2),n(:,1),n(:,2)];

ceq=[J(:,1).*J(:,3)+J(:,2).*J(:,4);J(:,3).^2+J(:,4).^2-1];

Gceq = jacobian(ceq,x).';

matlabFunction(ceq,[],Gceq,[],'file','ortho_p2p_con_sym.m','vars',{x},'outputs',{'c','ceq','Gc','Gceq'});