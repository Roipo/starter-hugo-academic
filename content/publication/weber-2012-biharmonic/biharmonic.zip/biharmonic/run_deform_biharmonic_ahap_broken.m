close all
filename = 'bar';
[X,Faces] = read_off([filename '.off']);
T = faces2tri(Faces);
patch('Faces',T,'Vertices',X,'FaceColor','w'); axis equal; hold on; grid minor
aa = axis;
aa = aa + [-1,1,-1,1];
axis(aa);

[x,y] = getline(gcf,'closed');
x = x(1:end-1); y = y(1:end-1);
drawPolygon(x,y);
draw_point_2d([x,y],'MarkerSize',30);

npinned = length(x);

zb = x +1i*y;
Hs = build_sampling_matrix(zb, 1, 1, 0);
zbs=Hs*zb;
dens = 100;

z = X(:,1) + 1i*X(:,2);
%zt=1./conj(zt);

[Phi,Psi,Alpha,Beta] = build_green_biharmonic_matrix(z, zbs);
[Phib,Psib,Alphab,Betab,H,zt] = build_green_biharmonic_matrix_boundary(zbs, dens);

Hn=(H~=0);
idx = repmat({':'}, ndims(Hn), 1); % initialize subscripts
n = size(Hn, 2); % length along dimension dim
idx{2} = [ 2:n 1 ];
Hn=Hn+Hn(idx{:});
Hn=(Hn==2);

T1=pinv(Psib)*(H-Phib);
M=Betab*T1+Alphab;
pinvM=pinv(M);

Phib_Psib=[H-Phib,-Psib];
T2=pinvM*Phib_Psib;

T2_left=T2(:,1:length(zbs));
T2_right=T2(:,length(zbs)+1:end);

AB_T1=Beta*T1+Alpha;
W=AB_T1*T2;
Alpha=W(:,1:length(zbs))+Phi;
Beta=W(:,length(zbs)+1:end)+Psi;



Xc = X;
xpinned = [x,y];


patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
drawPolygon(xpinned(:,1),xpinned(:,2));
draw_point_2d(xpinned,'MarkerSize',30);



while (1)
    l1 = pick_vertex(xpinned);
    draw_point_2d(xpinned(l1,:),'MarkerSize',30,'color','r');
    [zx,zy] = ginput(1);
    xpinned(l1,:) = [zx,zy];
    zb = xpinned(:,1)+1i*xpinned(:,2);
    zbs=Hs*zb;
    zn=(-1i)*[zbs(2:end)-zbs(1:end-1);zbs(1)-zbs(end)];
    %zn=Hn*zn
    zn=zn./abs(zn);
    %zbzn=[zb;zn];
    
    z1=Alpha*zbs;
    R=T2_left*zbs;
    R_real=[real(R);imag(R)];
    Q=-[diag(real(zn));diag(imag(zn))]*T2_right;
    pinvQ=pinv(Q);
    scalars=pinvQ*R_real;
    zn=zn.*scalars;
    z1=z1+Beta*zn;
    Xc = [real(z1), imag(z1)];
    
    cla
    patch('Faces',T,'Vertices',Xc,'FaceColor','none','EdgeColor','k'); axis equal; hold on; grid off
    drawPolygon(xpinned(:,1),xpinned(:,2));
    draw_point_2d(xpinned,'MarkerSize',30);
    axis(aa)
    title('Biharmonic');

end
