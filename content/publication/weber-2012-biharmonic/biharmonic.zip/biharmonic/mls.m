function [fv,fvs] = mls(p,q,v)

np = length(p);
vv = repmat(v,np,1);

alph = 1;
w = 1./(normv(p-vv)).^(2*alph);
ww = repmat(w,1,2);

pstar = sum(ww.*p)/sum(w);
qstar = sum(ww.*q)/sum(w);

ph = p - repmat(pstar,np,1);
qh = q - repmat(qstar,np,1);

M1 = zeros(2,2);
for i=1:np
    M1 = M1+ph(i,:)'*w(i)*ph(i,:);
end
M2 = zeros(2,2);
for i=1:np
    M2 = M2+w(i)*ph(i,:)'*qh(i,:);
end

M = inv(M1)*M2;

fv = (v-pstar)*M + qstar;

mus = 0;
for i=1:np
    mus = mus+w(i)*ph(i,:)*ph(i,:)';
end

R90 = [0,1;-1,0];
fvs = 0;
for i=1:np
    A{i} = w(i)*[ph(i,:);-ph(i,:)*R90]*[v-pstar; -(v-pstar)*R90]';
    fvs = fvs + qh(i,:)*(1/mus)*A{i};
end
fvs = fvs + qstar;



